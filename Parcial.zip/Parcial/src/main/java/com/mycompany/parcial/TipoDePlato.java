package com.mycompany.parcial;

public abstract class TipoDePlato{
    private final String nombre;
    private double precio;
    private TipoDePreparacion tipoPreparacion;

    public TipoDePlato(String nombre, double precio, TipoDePreparacion tipoPreparacion) {
        this.nombre = nombre;
        this.precio = precio;
        this.tipoPreparacion = tipoPreparacion;
    }
    
    private String getNombre(){
        return nombre;
    }
    private double getPrecio(){
        return precio;
    }
    private TipoDePreparacion getTipoDePreparacion(){
        return tipoPreparacion;
    }
    
    private String mostrarAtributosEspecificos(){
        return "";
    }
}
