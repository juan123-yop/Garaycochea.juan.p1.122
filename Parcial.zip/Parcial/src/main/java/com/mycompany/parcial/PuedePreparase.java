package com.mycompany.parcial;
 
public interface PuedePreparase {
    void puedePreparace();
}
