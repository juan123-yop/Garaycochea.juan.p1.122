package com.mycompany.parcial;

public class entrada extends TipoDePlato implements PuedePreparase{
    private final int cantidadDeIngredientes;
    
    public entrada(String nombre, double precio, TipoDePreparacion tipoPreparacion,int cantidadDeIngredientes){
        super(nombre, precio, tipoPreparacion);
        this.cantidadDeIngredientes = cantidadDeIngredientes;
    }
    public int getCantidadDeIngredientes(){
        return cantidadDeIngredientes;
    }
    public String mostrarAtributosEspecificos(){
        return "La cantidad de ingredientes usados es:" + cantidadDeIngredientes;
    }
    @Override
    public void puedePreparace() {
        System.out.println("Su plato esta en preparacion");
    }
    
}
