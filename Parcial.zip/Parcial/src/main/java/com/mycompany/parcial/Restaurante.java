package com.mycompany.parcial;

import java.util.ArrayList;
import java.util.List;

public class Restaurante {
    private List<TipoDePlato> plato;
    
    public Restaurante(TipoDePlato plato){
        this.plato = new ArrayList<>();
    }
    public void agregarPlato(TipoDePlato p){
        if (plato.contains(p)){
            throw new PlatoDuplicadoException();
        }
        plato.add(p);
    }
    public void mostrarPlatos(String TipoDePlato){
        for()
    }
    public void prepararPlato(){
        if (plato.isEmpty()) {
            System.out.println(" No hay platos registrados.");
        }
        System.out.println("\n--- Lista de Platos Registrados ---");
        for (TipoDePlato p : plato) {
            System.out.println();
        }
        System.out.println("-----------------------------------");
    }
    public void decorarPlato(){
    
    }
+filtrarPorTipoPreparacion(TipoPreparacion tipo)
+mostrarPlatosPorTipo(Str
}
