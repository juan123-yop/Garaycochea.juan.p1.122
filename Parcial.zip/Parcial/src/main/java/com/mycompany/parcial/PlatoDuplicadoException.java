package com.mycompany.parcial;

public class PlatoDuplicadoException extends Exception{
    public PlatoDuplicadoException(String nombre, TipoDePreparacion tipo){
        System.out.println("Error: Ya existe un plato con el nombre " + nombre + "\n" +
              " y tipo de preparación " + tipo + " en el sistema.");
    }
}
