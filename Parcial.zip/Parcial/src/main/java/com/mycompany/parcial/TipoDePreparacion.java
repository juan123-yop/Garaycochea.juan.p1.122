package com.mycompany.parcial;

public enum TipoDePreparacion {
    FRIA,
    CALIENTE
}
