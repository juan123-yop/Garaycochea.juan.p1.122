package com.mycompany.parcial;

public class Postre extends TipoDePlato implements sePuedeDecorar {
    private boolean contieneAzucar;
    
    public Postre(String nombre, double precio, TipoDePreparacion tipoPreparacion, boolean contieneAzucar){
        super(nombre, precio, tipoPreparacion);
        this.contieneAzucar = contieneAzucar;
    }
    public void contieneAzucar(){
        if (contieneAzucar == false){
            System.out.println("este postre no contiene azucar");
        }
        System.out.println("este postre contiene azucar");
    }
    public String mostrarAtributosEspecificos(){
        contieneAzucar();
        return 
    }
    @Override
    public void puedePreparace() {
        System.out.println("Su plato esta en preparacion");
    }
}
