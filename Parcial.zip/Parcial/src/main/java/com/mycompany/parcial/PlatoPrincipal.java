package com.mycompany.parcial;

public class PlatoPrincipal extends TipoDePlato implements PuedePreparase {
    private double tiempoDeCoccion;
    
    public PlatoPrincipal(String nombre, double precio, TipoDePreparacion tipoPreparacion, double tiempoDeCoccion){
        super(nombre, precio, tipoPreparacion);
        this.tiempoDeCoccion = tiempoDeCoccion;
    }
    public double getTiempoCoccion(){
        return tiempoDeCoccion;
    }
    public String mostrarAtributosEspecificos(){
        return "La cantidad de tiempo de coccion del plato es:" + tiempoDeCoccion;
    }
    @Override
    public void puedePreparace() {
        System.out.println("Su plato esta en preparacion");
    }
    
}
