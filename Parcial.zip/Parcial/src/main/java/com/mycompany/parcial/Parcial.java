/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parcial;

/**
 *
 * @author garay
 */
public class Parcial {

    public static void main(String[] args) {
        Restaurante miRestaurante = new Restaurante();

        // 1. Agregar platos al sistema (incluyendo el caso de excepción)
        try {
            // Entradas
            miRestaurante.agregarPlato(new entrada("Bruschetta", 15.50, TipoDePreparacion.FRIA, 5));
            miRestaurante.agregarPlato(new entrada("Sopa de Cebolla", 12.00, TipoDePreparacion.CALIENTE, 8));
            
            // Platos Principales
            miRestaurante.agregarPlato(new PlatoPrincipal("Solomillo Wellington", 45.00, TipoDePreparacion.CALIENTE, 35));
            miRestaurante.agregarPlato(new PlatoPrincipal("Ensalada César", 20.00, TipoDePreparacion.FRIA, 0)); // No cocción, pero preparación fría
            
            // Postres
            miRestaurante.agregarPlato(new Postre("Tiramisú", 18.00, TipoDePreparacion.FRIA, true));
            miRestaurante.agregarPlato(new Postre("Creme Brulee", 16.00, TipoDePreparacion.CALIENTE, true));

            // Intento de agregar un duplicado (Mismo Nombre y Tipo de Preparación)
            System.out.println("\n--- Intento de Agregar Duplicado ---");
            miRestaurante.agregarPlato(new entrada("Bruschetta", 10.00, TipoDePreparacion.FRIA, 3));
        catch {}
        }
}
