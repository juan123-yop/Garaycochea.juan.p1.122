package com.mycompany.parcial;
 
public interface sePuedeDecorar {
    void sePuedeDecorar();
    
}
